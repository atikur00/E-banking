<?php
include "../Model/DatabaseConnection.php";
    session_start();
    if(isset($_SESSION["bnk_login"])) {
        header("Location: dashboard.php");
        exit(0);
    }

    $errors = array();

    $registered = array();

    if(isset($_SESSION["bnk_register"])) {
        $registered = $_SESSION["bnk_register"];
        unset($_SESSION["bnk_register"]);
    }

    if($_SERVER['REQUEST_METHOD'] === "POST") {
        $userName = isset($_POST["username"]) ? test_input($_POST["username"]) : "";
        $password = isset($_POST["password"]) ? test_input($_POST["password"]) : "";

        if(empty($userName)) {
            $errors["username"] = "Please Enter Username";
        } 
        
        // else if(!in_array($userName, getUserNames())) {
        //     $errors["username"] = "Username doesn't match";
        // }

        if(empty($password)) {
            $errors["password"] = "Please Enter Password";
        } 
        // else if(!isset($errors["username"]) && !verifyPassword($userName, $password)) {
        //     $errors["password"] = "Password doesn't match";
        // }

        if(empty($errors)) {


            $connection=new DatabaseConnection();
            $conobj=$connection->OpenCon();
            $result=$connection->Login($conobj,"users",$userName,$password);
            
            if ($result->num_rows > 0)
            {
               while($row = $result->fetch_assoc())
               {
               echo "Name: " . $row["FirstName"]. " - Email: " . $row["Email"]."Username : ".$row["Username"]."<br>";
               $_SESSION['FName']= $row["FirstName"];
               $_SESSION["LName"]=$row["LastName"];
               $_SESSION['Username']=$row["Username"];
               $_SESSION['Email']=$row["Email"];
               }
        

            }
          $connection->CloseCon($conobj);
        

            // $users = getUsers();
            // $user = $users[$userName];
            // unset($user["password"]);
            // $_SESSION["bnk_login"] = $user;
            // header("Location: ../dashboard.php");
            // exit(0);
        }
    }
?>