<!doctype html>
<head>
<style>
body {
  background-color: lightblue;
}

h1 {
  color: white;
  text-align: center;
}

p {
  font-family: verdana;
  font-size: 20px;
}
a{
  text-decoration:none;
}
</style>
</head>
<body>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>E-Banking | Help Line</title>
</head>
<body>
<h1 style="background-color:MediumSeaGreen;">E-Banking - Help Line [ <a href="dashboard.php">Dashboard</a> ]</h1>
<h4>In case of lost/stolen card</h4>
<ol>
    <li>Contact home branch or</li>
    <li>Call our 24-hours Call Center at 16216 to block the card immediately,</li>
    <li>Submit a card replacement request to the home branch for a new card,</li>
    <li>You will get the replacement card within shortest possible time.</li>
</ol>
</body>
</html>