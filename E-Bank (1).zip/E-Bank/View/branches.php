<!doctype html>
<head>
<style>
body {
  background-color: lightblue;
}

h1 {
  color: white;
  text-align: center;
}

p {
  font-family: verdana;
  font-size: 20px;
}
a{
  text-decoration:none;
}
</style>
</head>
<body>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>E-Banking | Frequently Asked Questions</title>
</head>
<body>
<h1 style="background-color:MediumSeaGreen;">E-Banking - Branch Locations [ <a href="dashboard.php">Dashboard</a> ]</h1>
<table>
    <tbody>
    <tr>
        <th>SL No</th>
        <th>Sub SL</th>
        <th>Branch ID</th>
        <th>Branch Name</th>
        <th>Address</th>
    </tr>

    <tr>
        <td>1</td>
        <td>1</td>
        <td>101</td>
        <td>Local Office</td>
        <td>1, Dilkusha Commercial Area, Dhaka-1000</td>
    </tr>


    <tr>
        <td>2</td>
        <td>2</td>
        <td>103</td>
        <td>Banani Branch</td>
        <td>1st and 2nd Floor, Borak Mehnur, 51/B Kamal Ataturk Avenue, Banani, Dhaka-1213</td>
    </tr>

    <tr>
        <td>3</td>
        <td>3</td>
        <td>104</td>
        <td>Nababpur Branch</td>
        <td>165, Nababpur Road, Dhaka-1000</td>
    </tr>


    <tr>
        <td>4</td>
        <td>4</td>
        <td>105</td>
        <td>Motijheel Foreign Exchange Branch</td>
        <td>City Centre, Holding# 90/1, Motijheel Commercial Area, Dhaka-1000</td>
    </tr>

    <tr>
        <td>5</td>
        <td>5</td>
        <td>107</td>
        <td>Kawran Bazar Branch</td>
        <td>BTMC Bhaban (1st Floor), 7/9, Kawran Bazar, Dhaka-1215</td>
    </tr>


    <tr>
        <td>6</td>
        <td>6</td>
        <td>108</td>
        <td>Shantinagar Branch</td>
        <td>41, Chamelibagh,(Green Peace), Shantinagar, Dhaka-1217</td>
    </tr>

    <tr>
        <td>7</td>
        <td>7</td>
        <td>110</td>
        <td>Dhanmondi Branch</td>
        <td>Bays Park Height (Gr. and 1st Floor), Road#9, Holding#2, Dhanmondi, Dhaka-1209</td>
    </tr>


    <tr>
        <td>8</td>
        <td>8</td>
        <td>114</td>
        <td>Mohakhali Branch</td>
        <td>Hotel Zakaria (1st Floor), 35 Gulshan Road, Mohakhali C/A, Dhaka - 1212</td>
    </tr>

    <tr>
        <td>9</td>
        <td>9</td>
        <td>115</td>
        <td>Mirpur Branch</td>
        <td>8, Darus Salam Road, Mirpur -1, Dhaka-1216</td>
    </tr>


    <tr>
        <td>10</td>
        <td>10</td>
        <td>116</td>
        <td>Gulshan Branch</td>
        <td>The Grand Delvistaa,CES (A) 1/A, Road # 113,Gulshan Avenue, Dhaka-1212</td>
    </tr>

    <tr>
        <td>11</td>
        <td>11</td>
        <td>117</td>
        <td>Uttara Branch</td>
        <td>Plot No.7, Road No.7, Sector No.4, Uttara Residential Area, Uttara, Dhaka-1230</td>
    </tr>


    <tr>
        <td>12</td>
        <td>12</td>
        <td>118</td>
        <td>Islampur Branch</td>
        <td>Jahangir Tower, 2nd Floor, 114, 115, 116, Islampur Road, Dhaka-1100</td>
    </tr>

    <tr>
        <td>13</td>
        <td>13</td>
        <td>119</td>
        <td>Dania Branch</td>
        <td>Ayesha Mosarraf Shopping Complex, Shyampur, Dhaka</td>
    </tr>


    <tr>
        <td>14</td>
        <td>14</td>
        <td>122</td>
        <td>Dhaka EPZ Branch</td>
        <td>Baipail, Savar, Dhaka</td>
    </tr>

    <tr>
        <td>15</td>
        <td>15</td>
        <td>126</td>
        <td>Elephant Road Branch</td>
        <td>1st, 2nd &amp; 3rd Floors, Dom-Inno ESTRELLA, 129 Elephant Road, Dhaka-1205</td>
    </tr>


    <tr>
        <td>16</td>
        <td>16</td>
        <td>130</td>
        <td>Joypara Branch</td>
        <td>Monowara Mansion, 1st Floor, Joypara, Mouja-Lota Khola, Thana-Dohar, Dhaka</td>
    </tr>

    <tr>
        <td>17</td>
        <td>17</td>
        <td>136</td>
        <td>Nayabazar Branch</td>
        <td>29/1 North South Road, 2nd Floor, Bangshal, Dhaka</td>
    </tr>


    <tr>
        <td>18</td>
        <td>18</td>
        <td>137</td>
        <td>Savar Bazar Branch</td>
        <td>A-44, Amin Tower, 2nd Floor, Savar Bazar, Dhaka</td>
    </tr>

    <tr>
        <td>19</td>
        <td>19</td>
        <td>139</td>
        <td>Imamganj Branch</td>
        <td>Holding# 22/1-23, 2nd &amp; 3rd Floor, Roy Iswar Chandra Seal Bahadur Street, Imamgonj, Dhaka</td>
    </tr>


    <tr>
        <td>20</td>
        <td>20</td>
        <td>147</td>
        <td>Bashundhara Branch</td>
        <td>K 3/1-C, Jogonnathpur, Bashundhara, Dhaka</td>
    </tr>

    <tr>
        <td>21</td>
        <td>21</td>
        <td>148</td>
        <td>Shyamoli Branch</td>
        <td>Shyamoli Cinema Complex, Plot# 23/8B and 23/8C, Holding No. 24/1 and 24/2, Mohammadpur, Dhaka</td>
    </tr>


    <tr>
        <td>22</td>
        <td>22</td>
        <td>160</td>
        <td>Bandura Branch</td>
        <td>Shezan Multi Shopping Mall (1st Floor), Bandura Bazar, Nawabgonj, Dhaka</td>
    </tr>

    <tr>
        <td>23</td>
        <td>23</td>
        <td>164</td>
        <td>Mirpur Circle-10 Branch</td>
        <td>Gemcon EI Mercado 2nd and 3rd Floor, 114 Begum Rokeya Sarani, Mirpur, Dhaka</td>
    </tr>


    <tr>
        <td>24</td>
        <td>24</td>
        <td>171</td>
        <td>Satmosjid Road Branch</td>
        <td>Plot # 47, Road # 9/A, Dhanmondi R/A, Dhaka-1209</td>
    </tr>

    <tr>
        <td>25</td>
        <td>25</td>
        <td>178</td>
        <td>Rampura Branch</td>
        <td>2/1, East Rampura, DIT Road, Rampura, Dhaka</td>
    </tr>


    <tr>
        <td>26</td>
        <td>26</td>
        <td>183</td>
        <td>Dakshinkhan SME/Agriculture Branch</td>
        <td>Rajob Ali Super Market, 83, Dakshinkhan Bazar,Uttara,Dhaka</td>
    </tr>

    <tr>
        <td>27</td>
        <td>27</td>
        <td>191</td>
        <td>Bijoynagar Branch</td>
        <td>1st&amp;2nd Floor of 180-81,Shahid Syed Nazrul Islam Shoroni,Bijoynagar,Dhaka</td>
    </tr>


    <tr>
        <td>28</td>
        <td>28</td>
        <td>193</td>
        <td>Progoti Shoroni Branch</td>
        <td>Azhar Comfort Complex (1st floor),GA-130/A, Progoti Shoroni, Middle Badda, Dhaka-1212</td>
    </tr>

    <tr>
        <td>29</td>
        <td>29</td>
        <td>197</td>
        <td>Matuail Branch</td>
        <td>Meghna Plaza,Konapara Main Road,Union-Matuail, PS-Jatrabari,Dhaka</td>
    </tr>


    <tr>
        <td>30</td>
        <td>30</td>
        <td>198</td>
        <td>Keraniganj Branch</td>
        <td>Jahanara Plaza, Shahid Nagar,(Dakpara),Keraniganj,Dhaka</td>
    </tr>

    <tr>
        <td>31</td>
        <td>31</td>
        <td>199</td>
        <td>Uttara Sonargaon Janopad Branch</td>
        <td>Plot no-2,Sonargaon Janapad Road,Sector no-11, Uttara Residential Area,Dhaka-1230</td>
    </tr>


    <tr>
        <td>32</td>
        <td>32</td>
        <td>202</td>
        <td>Ashkona Branch</td>
        <td>Bhuiyan Shopping Complex, 301-631 Ashkona, Dhaka</td>
    </tr>

    <tr>
        <td>33</td>
        <td>33</td>
        <td>208</td>
        <td>Vatara Branch</td>
        <td>Sahida Plaza, Solmaid, Vatara, Badda, Dhaka</td>
    </tr>


    <tr>
        <td>34</td>
        <td>34</td>
        <td>211</td>
        <td>Pallabi Branch</td>
        <td>Northern Khan Heights, Plot No-34, Road No-3, Block-D, Section-11, Mirpur, PS-Pallabi, Dhaka</td>
    </tr>

    <tr>
        <td>35</td>
        <td>35</td>
        <td>214</td>
        <td>Uttarkhan Branch</td>
        <td>Kazi Tower,  Master Para,  Uttar Khan, Dhaka</td>
    </tr>


    <tr>
        <td>36</td>
        <td>36</td>
        <td>216</td>
        <td>Ashulia Branch</td>
        <td>Jamgora, Ashulia, Dhaka</td>
    </tr>

    <tr>
        <td>37</td>
        <td>37</td>
        <td>217</td>
        <td>Ruhitpur Branch</td>
        <td>Khokon Tower, Ruhitpur Boarding Market, Ruhitpur Bazar, Keranigonj,  Dhaka</td>
    </tr>


    <tr>
        <td>38</td>
        <td>38</td>
        <td>221</td>
        <td>Manda Branch</td>
        <td>1st Floor, Uttar Manda (Main Road), Dhaka</td>
    </tr>

    <tr>
        <td>39</td>
        <td>39</td>
        <td>222</td>
        <td>Ati Bazar Branch</td>
        <td>1st Floor, Ati Bazar, Keraniganj, Dhaka</td>
    </tr>


    <tr>
        <td>40</td>
        <td>40</td>
        <td>223</td>
        <td>Aminbazar Branch</td>
        <td>Begunbari, Aminbazar, Dhaka</td>
    </tr>

    <tr>
        <td>41</td>
        <td>41</td>
        <td>224</td>
        <td>Wari Branch</td>
        <td>S.B.A.L. Shahadat Bilash, 25  Rankin Street, Wari, Sutrapur Dhaka</td>
    </tr>


    <tr>
        <td>42</td>
        <td>42</td>
        <td>227</td>
        <td>Tejgaon Branch</td>
        <td>315/B, Shahid Tajuddin Sarani, PS - Tejgaon l/A, Dhaka</td>
    </tr>

    <tr>
        <td>43</td>
        <td>43</td>
        <td>230</td>
        <td>Abdullahpur Branch</td>
        <td>Anwar Hossain Plaza, Abdullahpur Bus Stand, Kolakandi Road, Keraniganj, Dhaka</td>
    </tr>


    <tr>
        <td>44</td>
        <td>44</td>
        <td>234</td>
        <td>Kalampur Branch</td>
        <td>Kalampur Bazar, Dhamrai, Dhaka</td>
    </tr>

    <tr>
        <td>45</td>
        <td>45</td>
        <td>236</td>
        <td>Dumni Branch</td>
        <td>Dumni Bazar, Khilkhet, Dhaka</td>
    </tr>


    <tr>
        <td>46</td>
        <td>46</td>
        <td>244</td>
        <td>Hemayetpur Branch</td>
        <td>Hazi Ashraf Shopping Complex, 1st floor, Hemayetpur Bus Stand, Savar, Dhaka</td>
    </tr>

    <tr>
        <td>47</td>
        <td>47</td>
        <td>245</td>
        <td>Zirabo Branch</td>
        <td>Zirabo Bus Stand, Ashulia, Savar, Dhaka</td>
    </tr>


    <tr>
        <td>48</td>
        <td>48</td>
        <td>246</td>
        <td>Gulshan Circle-1 Branch</td>
        <td>1st floor, Bays 23 Gulshan Avenue, Plot No. 6, Block No. SW(I), Gulshan Model Town, Dhaka-1212</td>
    </tr>

    <tr>
        <td>49</td>
        <td>49</td>
        <td>255</td>
        <td>Panthapath Branch</td>
        <td>Ena Shakur Emarat, 19/3, 1st Floor,West Panthapath, Dhaka</td>
    </tr>


    <tr>
        <td>50</td>
        <td>50</td>
        <td>257</td>
        <td>Aganagar Branch</td>
        <td>Mayaz Tower, 1st &amp; 2nd Floor, Aganagar, Kaliganj, Keraniganj, Dhaka</td>
    </tr>

    <tr>
        <td>51</td>
        <td>51</td>
        <td>258</td>
        <td>Mohammadpur Branch</td>
        <td>75/C, 1st, 2nd and 3rd Floor, Asad Avenue, Mohammadpur, Dhaka</td>
    </tr>


    <tr>
        <td>52</td>
        <td>52</td>
        <td>260</td>
        <td>Hasnabad Branch</td>
        <td>Mafizuddin Mansion, 2nd Floor, Holding No. 1, Container Port Road, Hasnabad, South Keraniganj, Dhaka</td>
    </tr>

    <tr>
        <td>53</td>
        <td>53</td>
        <td>270</td>
        <td>Savar Palli Bidyut Branch</td>
        <td>2nd Floor, Hazi Nizam Plaza, Dendabor, Savar Cantonment, Ashulia, Savar</td>
    </tr>


    <tr>
        <td>54</td>
        <td>54</td>
        <td>271</td>
        <td>Nawabgonj Branch</td>
        <td>Raju Complex, Kalakopa, Nawabgonj</td>
    </tr>

    <tr>
        <td>55</td>
        <td>55</td>
        <td>275</td>
        <td>New Market Branch</td>
        <td>1st and 2nd Floor, Golden Gate Shopping Center, 28 Mirpur Road, New Market</td>
    </tr>


    <tr>
        <td>56</td>
        <td>56</td>
        <td>276</td>
        <td>Corporate Branch</td>
        <td>47 Motijheel C/A, Dhaka-1000</td>
    </tr>

    <tr>
        <td>57</td>
        <td>57</td>
        <td>277</td>
        <td>Ashulia Bazar Branch</td>
        <td>1st Floor, Ashulia Newmarket, Ashulia Bazar, Ashulia</td>
    </tr>


    <tr>
        <td>58</td>
        <td>58</td>
        <td>286</td>
        <td>Moghbazar Branch</td>
        <td>1st Floor, Green Satmahal, 206,207,208 Boro Moghbazar, Moghbazar</td>
    </tr>

    <tr>
        <td>59</td>
        <td>59</td>
        <td>287</td>
        <td>Kamarpara Branch</td>
        <td>1st Floor, Hazi Ramzan Ali Tower, 33 Kamarpara, Turag, Dhaka</td>
    </tr>


    <tr>
        <td>60</td>
        <td>60</td>
        <td>292</td>
        <td>Khilgaon Branch</td>
        <td>R.N Square (1st &amp; 2nd Floor), 552/C, Khilgaon, Dhaka-1219</td>
    </tr>

    <tr>
        <td>61</td>
        <td>61</td>
        <td>293</td>
        <td>Baraipara Branch</td>
        <td>Sufia Mansion, Nabinagar, Chandura Highway, Baraipara, Ashulia, Dhaka</td>
    </tr>


    <tr>
        <td>62</td>
        <td>62</td>
        <td>300</td>
        <td>Ibrahimpur Branch</td>
        <td>83 Ibrahimpur, Main Road, Kafrul, Dhaka</td>
    </tr>

    <tr>
        <td>63</td>
        <td>63</td>
        <td>303</td>
        <td>Banasree Branch</td>
        <td>1st Floor, F2-3, Main Road, Banasree, Dhaka</td>
    </tr>


    <tr>
        <td>64</td>
        <td>64</td>
        <td>305</td>
        <td>Dholaikhal Branch</td>
        <td>1st Floor, 40/1/A, Lal Mohon Saha Street, Dholaikhal, Dhaka</td>
    </tr>

    <tr>
        <td>65</td>
        <td>65</td>
        <td>307</td>
        <td>Kalatia Branch</td>
        <td>1st Floor, Darani Master Plaza, Holding# 9/1, Kalatia Bazar, Keraniganj, Dhaka</td>
    </tr>


    <tr>
        <td>66</td>
        <td>66</td>
        <td>308</td>
        <td>Shewrapara Branch</td>
        <td>1st Floor, Holding# 888/1, Shewrapara, Mirpur, Dhaka</td>
    </tr>

    <tr>
        <td>67</td>
        <td>67</td>
        <td>311</td>
        <td>Bangabandhu Avenue Branch</td>
        <td>Hossain Chamber, 1st and 2nd Floor, 30 Bangabandhu Avenue, Dhaka-1000</td>
    </tr>


    <tr>
        <td>68</td>
        <td>68</td>
        <td>313</td>
        <td>Norsinghpur Branch</td>
        <td>Hashem Trade Center (1st Floor), Norsinghpur Bazar, DEPZ Road, Ashulia, Dhaka</td>
    </tr>

    <tr>
        <td>69</td>
        <td>69</td>
        <td>321</td>
        <td>Rabindra Sarani Branch</td>
        <td>Green Reflections (1st and 2nd Floor), Holding No. 33, Road# 15, Rabindra Sarani, Sector# 3, Uttara,</td>
    </tr>
    </tbody>
</table>
</body>
</html>