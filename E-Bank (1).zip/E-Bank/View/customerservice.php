<!doctype html>
<head>
<style>
body {
  background-color: lightblue;
}

h1 {
  color: white;
  text-align: center;
}

p {
  font-family: verdana;
  font-size: 20px;
}
a{
  text-decoration:none;
}
</style>
</head>
<body>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>E-Banking | Customer Service</title>
</head>
<body>
<h1 style="background-color:MediumSeaGreen;">E-Banking - Customer Service [ <a href="dashboard.php">Dashboard</a> ]</h1>
<h2></h2>
<h4>Debit / Credit Cards</h4>
<hr>
Dutch-Bangla Bank family, always believe that, as in everything else, you deserve the best in banking too. Therefore, we constantly strive to cater to all your financial needs with world class products to become your trusted partner. If you need any information or assistance about a service or a product, please let us know. We are here to assist you 365 days round the clock through our Customer Care Center.
<ol>
    <li>Call our 24-hours Call Center at 16216. For International Call 09xxxxx.</li>
    <li>Click to send an e-mail to: cards@ebank.com</li>
    <li>Visit the Help Desk at any E-Bank Branch or</li>
    <li>Write to us at:</li>
</ol>
<address>
    E-Bank Limited<br>
    Cards Operation Division, Head Office<br>
    315/B (2nd Floor)<br>
    Kuratoli<br>
    Dhaka - 1208<br>
    Bangladesh<br>
</address>
<h4>Internet Banking</h4>
<hr>
If you need help with the log in process of Internet Banking or have technical question, please let us know. We are here to assist you 365 days round the clock through our Customer Care Center.
<ol>
    <li>Call our 24-hours Call Center at 16216. For International Call 09xxxxx.</li>
    <li>Internet Banking Support can be reached via e-mail at ibsupport@ebank.com</li>
    <li>Write to us at:</li>
</ol>
<address>
    E-Bank Limited<br>
    Internet Banking Help Desk, Head Office<br>
    315/B (2nd Floor)<br>
    Kuratoli<br>
    Dhaka - 1208<br>
    Bangladesh<br>
</address>
<h4>SMS & Alert Banking</h4>
<hr>
If you need help for operation process of SMS & Alert Banking or have technical questions, please let us know. We are here to assist you 365 days round the clock through our Customer Care Center.
<ol>
    <li>Call our 24-hours Call Center at 16216. For International Call 09xxxxx.</li>
    <li>SMS & Alert Banking Support can be reached via e-mail at ibsupport@ebank.com</li>
    <li>Write to us at:</li>
</ol>
<address>
    E-Bank Limited<br>
    SMS & Alert Banking Help Desk, Head Office<br>
    315/B (2nd Floor)<br>
    Kuratoli<br>
    Dhaka - 1208<br>
    Bangladesh<br>
</address>
</body>
</html>