<!doctype html>
<head>
<style>
body {
  background-color: lightblue;
}

h1 {
  color: white;
  text-align: center;
}

p {
  font-family: verdana;
  font-size: 20px;
}
a{
  text-decoration:none;
}
</style>
</head>
<body>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>E-Banking | Frequently Asked Questions</title>
</head>
<body>
<h1 style="background-color:MediumSeaGreen;">E-Banking - Frequently Asked Questions [ <a href="dashboard.php">Dashboard</a> ]</h1>
<b>1.What are the cards that E-Bank Ltd provides ?</b><br>
E-Bank Ltd issues both Debit & Credit Cards.<br><br>

Debit cards: E-Bank Ltd-NEXUS Classic, MasterCard (Local & International), Visa Debit (Local & International).<br><br>

Credit cards: Visa (Local & International), MasterCard (Local & International).<br><br>

<b>2. What is the difference between MasterCard/Visa and Classic cards?</b><br>
MasterCard/Visa is the card with MasterCard/Visa brand which can be used at ATMs that have MasterCard/Visa logo and E-Bank Ltd-NEXUS Classic card is the proprietorship card of E-Bank Ltd that can be used only at E-Bank Ltd ATMs.<br><br>

<b>3. Can I use MasterCard/Visa/Classic card for shopping?</b><br>
Any E-Bank Ltd MasterCard/Visa/Classic card can be used for shopping<br><br>

<b>4. How can I get a debit card/credit card?</b><br>
Debit card: a person has to open an account at any E-Bank Ltd branch. For international debit card one has to have an ERQ/RFCD/FC account with E-Bank Ltd.<br><br>

Credit card: A filled out credit card application form along with the following has to be submitted to E-Bank Ltd Card Division or any of E-Bank Ltd branch:<br><br>

i) Photograph (one copy),<br>
ii) Copy of TIN certificate,<br>
iii) Copy of Passport (page 1 to 6 and renewal page) and National ID,<br>
iv) Proof of residence (copy of utility bills), if any,<br>
v) Bank statement for last 6 months,<br>
vi) If salaried, latest original salary certificate/pay slip,<br>
vii) If self-employed, copy of trade license/MOA and personal/company bank statement for the last 6 months,<br>
viii) Copy of wealth statement submitted for Income Tax/ IT 88 (for Businessmen),<br>
ix) Visiting card,<br>
x) Other credit card bill, if applicable.<br><br>

<b>5. I have received card through courier. What shall I do now?</b><br>
To activate, collect the PIN from home branch and submit the acknowledgement slip there.<br><br>

<b>6. How can I activate/reactivate my card?</b><br>
A card will be activated after submission of the acknowledgement slip/reactivation request to the home branch.<br><br>

<b>7. Can I use MasterCard/Visa/Classic card simultaneously?</b><br>
Yes, MasterCard/Visa/Classic card issued against an account can be used simultaneously.<br><br>

<b>8. My card was retained/captured by the ATM. How can I get it?</b><br>
In case of retained/captured card please contact: i) Home Branch or,<br>
ii) Call our 24-hours Call Center at 16216.<br><br>

<b>9. I've lost my card. What can I do now?</b><br>
Please contact home branch or call our 24 hours Call Center at 16216 to block the card immediately and submit a card replacement request to the home branch.<br><br>

<b>10. How can I get a replacement card?</b><br>
A filled out card replacement request form has to be submitted to the home branch.<br><br>

<b>11. Can I use E-Bank Ltd Classic card in other bank's ATM?</b><br>
E-Bank Ltd-NEXUS Classic card cannot be used at other bank's ATM.<br><br>

<b>12. How can I change my PIN?</b><br>
PIN can be changed at any of E-Bank Ltd ATM.<br><br>

<b>13.I've forgotten my PIN. What can I do now?</b><br>
Nothing to be worried!!! A PIN regeneration request form to be submitted to the home branch only. A new PIN will be sent to the home branch.<br><br>

<b>14.How can I get an over draft (OD) facility through card?</b><br>
A filled out OD application form to be submitted to any of E-Bank Ltd branches.<br><br>

<b>15.How can I renew my OD card?</b><br>
A renewal request form will be sent to the customer before the expiry. After filling out the form has to be submitted to E-Bank Ltd Card Division or to the home branch.<br><br>

<b>16. How can I get a POS machine at my shop?</b><br>
A Current Deposit (CD) account has to be opened at any E-Bank Ltd branch and a filled out Merchant Agreement Form to be submitted to E-Bank Ltd Card Division.<br><br>

<b>17.Can I use other banks' cards at E-Bank Ltd ATM?</b><br>
The following branded cards can be used at E-Bank Ltd ATMs:<br>
i) Any type of MasterCard (debit or credit),<br>
ii) Any type of Visa card (debit or credit), Visa Plus,<br><br>

<b>18.How can I open an Internet Banking Account.</b><br>
If you have an account with the E-Bank Limited(E-Bank Ltd), you are eligible to get the password for accessing Internet Banking. To get the "Password" you have to apply for it through your branch. The Application Form for obtaining the "Password" of Internet Banking is available in the "Form" menu of our web site or your home branch. You have to fill-in the Application Form and send to your branch for signature verification and onward submission to the Data Center. The Data Center will generate a "Password" for you and print in a secured "PIN Mailer". The PIN Mailer will be sent to you. Once you get the PIN Mailer, open it to get your "Password". When you will log-in the Internet Banking for the first time with this "Password", the system will force you to change it. You have to give a new password of your choice.<br><br>

<b>19. How can I open an SMS & Alert Banking Account.</b><br>
If you have an account with the E-Bank Limited (E-Bank Ltd) , you are eligible to get the SMS & Alert Banking PIN to access your account. For enabling SMS & Alert Banking you need to have a mobile connectivity. The application form (Customer Option Form) of SMS & Alert Banking is available to our web site or any E-Bank Ltd branch. You have to fill-in the Application Form and send to your branch or to the following address. The branch will enable your SMS & Alert Banking and alert your PIN to your mentioned mobile number. Please send the application to:<br><br>
<address>
Head of IT Operation Division<br>
E-Bank Ltd.(4th Floor)<br>
Plot # 47, Road # 9/A<br>
Satmosjid Road, Dhanmondi<br>
Dhaka -1205<br>
Bangladesh
</address>
</body>
</html>